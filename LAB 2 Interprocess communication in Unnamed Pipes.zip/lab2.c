#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>



// Helper to close unused pipe ends in parent/child
void close_pipes(int fd_read, int fd_write) {
    close(fd_read);
    close(fd_write);
}

/* TASK 1 */
/* Parent sends one integer to child using unnamed pipe */
void task1() {
    print_separator("TASK 1: Parent sends a single number to child");
    int fd[2];
    int num = 22;
    pipe(fd); // fd[0] for read, fd[1] for write

    if (fork() == 0) { // Child
        close_pipes(fd[1], -1); // Close write end of pipe (no -1 for write to indicate unused)
        int received;
        read(fd[0], &received, sizeof(received));
        printf("[Child] Received number: %d\n", received);
        close(fd[0]);
    } else { // Parent
        close_pipes(fd[0], -1); // Close read end of pipe
        printf("[Parent] Sending number: %d\n", num);
        write(fd[1], &num, sizeof(num));
        close(fd[1]);
        wait(NULL);
    }
}

/* TASK 2 */
/* Parent sends a number to child; child multiplies by 2 and sends back */
void task2() {
    print_separator("TASK 2: Child processes data and sends back result");
    int p_to_c[2], c_to_p[2]; // Parent to Child, Child to Parent
    int num = 61, result;

    pipe(p_to_c);
    pipe(c_to_p);

    if (fork() == 0) { // Child
        close_pipes(p_to_c[1], c_to_p[0]); // Close write end of p_to_c, read end of c_to_p
        read(p_to_c[0], &num, sizeof(num));
        result = num * 2;
        printf("[Child] Received: %d, Sending back: %d\n", num, result);
        write(c_to_p[1], &result, sizeof(result));
        close_pipes(p_to_c[0], c_to_p[1]);
    } else { // Parent
        close_pipes(p_to_c[0], c_to_p[1]); // Close read end of p_to_c, write end of c_to_p
        printf("[Parent] Sending number: %d\n", num);
        write(p_to_c[1], &num, sizeof(num));
        wait(NULL);
        read(c_to_p[0], &result, sizeof(result));
        printf("[Parent] Received result from child: %d\n", result);
        close_pipes(p_to_c[1], c_to_p[0]);
    }
}

/* TASK 3 */
/* Use wait() to synchronize communication */
void task3() {
    print_separator("TASK 3: Synchronization using wait()");
    int p_to_c[2], c_to_p[2];
    int num = 10, result;

    pipe(p_to_c);
    pipe(c_to_p);

    if (fork() == 0) { // Child
        close_pipes(p_to_c[1], c_to_p[0]);
        read(p_to_c[0], &num, sizeof(num));
        result = num + 100;
        printf("[Child] Processing: %d + 100 = %d\n", num, result);
        write(c_to_p[1], &result, sizeof(result));
        close_pipes(p_to_c[0], c_to_p[1]);
    } else { // Parent
        close_pipes(p_to_c[0], c_to_p[1]);
        printf("[Parent] Sending number: %d\n", num);
        write(p_to_c[1], &num, sizeof(num));
        wait(NULL);
        read(c_to_p[0], &result, sizeof(result));
        printf("[Parent] Received result: %d\n", result);
        close_pipes(p_to_c[1], c_to_p[0]);
    }
}

/* TASK 4 */
/* Parent sends multiple numbers, child sums them */
void task4() {
    print_separator("TASK 4: Sending multiple values");
    int p_to_c[2], c_to_p[2];
    int nums[] = {11, 6, 2, 18, 7};
    int sum = 0;
    int size = sizeof(nums) / sizeof(nums[0]);

    pipe(p_to_c);
    pipe(c_to_p);

    if (fork() == 0) { // Child
        close_pipes(p_to_c[1], c_to_p[0]);
        int recv_nums[size]; // Use 'size' for dynamic array if C99, otherwise allocate statically or dynamically
        read(p_to_c[0], recv_nums, sizeof(nums)); // Read entire array
        printf("[Child] Received numbers: ");
        for (int i = 0; i < size; i++) {
            printf("%d ", recv_nums[i]);
            sum += recv_nums[i];
        }
        printf("\n[Child] Computed sum: %d\n", sum);
        write(c_to_p[1], &sum, sizeof(sum));
        close_pipes(p_to_c[0], c_to_p[1]);
    } else { // Parent
        close_pipes(p_to_c[0], c_to_p[1]);
        printf("[Parent] Sending numbers: ");
        for (int i = 0; i < size; i++) printf("%d ", nums[i]);
        printf("\n");
        write(p_to_c[1], nums, sizeof(nums)); // Write entire array
        wait(NULL);
        read(c_to_p[0], &sum, sizeof(sum));
        printf("[Parent] Received sum from child: %d\n", sum);
        close_pipes(p_to_c[1], c_to_p[0]);
    }
}

/* TASK 5 */
/* Parent sends array, child returns average */
void task5() {
    print_separator("TASK 5: Sends array, get sum & average");
    int p_to_c[2], c_to_p[2];
    int nums[] = {1, 0, 3, 9, 22};
    int n = sizeof(nums) / sizeof(nums[0]);
    float avg;

    pipe(p_to_c);
    pipe(c_to_p);

    if (fork() == 0) { // Child
        close_pipes(p_to_c[1], c_to_p[0]);
        int arr[n]; // VLA, or use a fixed large size like 100 if n is always small
        read(p_to_c[0], arr, n * sizeof(int));
        int sum = 0;
        for (int i = 0; i < n; i++) sum += arr[i];
        avg = (float)sum / n;
        printf("[Child] Received numbers: ");
        for (int i = 0; i < n; i++) printf("%d ", arr[i]);
        printf("\n[Child] Sum = %d, Average = %.2f\n", sum, avg);
        write(c_to_p[1], &avg, sizeof(avg));
        close_pipes(p_to_c[0], c_to_p[1]);
    } else { // Parent
        close_pipes(p_to_c[0], c_to_p[1]);
        printf("[Parent] Sending numbers: ");
        for (int i = 0; i < n; i++) printf("%d ", nums[i]);
        printf("\n");
        write(p_to_c[1], nums, n * sizeof(int));
        wait(NULL);
        read(c_to_p[0], &avg, sizeof(avg));
        printf("[Parent] Received average: %.2f\n", avg);
        close_pipes(p_to_c[1], c_to_p[0]);
    }
}

/* MAIN FUNCTION */
int main() {
    printf(" IPC Lab \n");
    task1();
    task2();
    task3();
    task4();
    task5();
    printf("\n Task Simulation Complete \n");
    return 0;
}
